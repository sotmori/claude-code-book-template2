import{a as e,c as t,i as n,l as r,o as i,s as a}from"./index-BqZ4hbZF.js";import{DEMO_USERS as o,currentDemoUser as s,resetDemoData as c,switchDemoUser as l}from"./demo-backend-1o6QPigy.js";
/**
* @license lucide-react v1.64.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var u={name:`flask-conical`,size:24,node:[[`path`,{d:`M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2`,key:`18mbvz`}],[`path`,{d:`M6.453 15h11.094`,key:`3shlmq`}],[`path`,{d:`M8.5 2h7`,key:`csnxdl`}]]};u.node;var d=a(u),f={name:`rotate-ccw`,size:24,node:[[`path`,{d:`M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8`,key:`1357e3`}],[`path`,{d:`M3 3v5h5`,key:`1xhq8a`}]]}
/**
* @license lucide-react v1.64.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
;f.node;var p=a(f),m=r(t(),1),h=i();function g(){let t=s(),[r,i]=(0,m.useState)(!1);return(0,h.jsxs)(`div`,{className:`mb-4 flex flex-wrap items-center gap-3 rounded-md border border-warning/40 bg-warning-lightest px-4 py-2 text-sm`,children:[(0,h.jsx)(d,{size:16,className:`text-warning`,"aria-hidden":`true`}),(0,h.jsx)(`span`,{className:`font-medium`,children:`デモ版（ログイン不要・データはこのブラウザ内にのみ保存）`}),(0,h.jsxs)(`label`,{className:`ml-auto flex items-center gap-2`,children:[(0,h.jsx)(`span`,{className:`text-foreground-secondary`,children:`利用者を切り替え`}),(0,h.jsx)(`select`,{className:`h-8 rounded border border-border-strong bg-surface px-2`,value:t.principalId,onChange:e=>l(e.target.value),children:o.map(e=>(0,h.jsxs)(`option`,{value:e.principalId,children:[e.name,`（`,e.label,`）`]},e.principalId))})]}),(0,h.jsx)(e,{size:`sm`,variant:`ghost`,icon:(0,h.jsx)(p,{size:14}),onClick:()=>i(!0),children:`データを初期化`}),(0,h.jsx)(n,{open:r,title:`デモデータを初期化しますか？`,message:`作成した申請と添付した領収書をすべて削除し、サンプルデータに戻します。`,confirmLabel:`初期化する`,destructive:!0,onConfirm:c,onCancel:()=>i(!1)})]})}export{g as default};